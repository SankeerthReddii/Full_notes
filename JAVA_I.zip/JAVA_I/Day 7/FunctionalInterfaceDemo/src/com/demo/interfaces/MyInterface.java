package com.demo.interfaces;

public interface MyInterface<F,T>{
      T compare(F x,F y);
}

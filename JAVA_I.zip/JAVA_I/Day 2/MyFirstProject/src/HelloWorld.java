
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!!");
		byte b=127;
		Byte bob=b; //boxing
		byte x=bob; //unboxing
		System.out.println("b: "+b);
		float f=45.678f;
		double d=56.789;
		char ch='d';
		boolean b1=true;
	}

}
